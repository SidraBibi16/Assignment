const fs = require('fs');
const path = require('path');

const USERS_DIR = path.join(__dirname, '..', 'users');
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');

exports.getPictures = (req, res) => {
  const username = req.query.username;
  if (!username) return res.status(400).send('Username required');

  const userPath = path.join(USERS_DIR, `${username}.json`);
  if (!fs.existsSync(userPath)) return res.status(404).send('User not found');

  const currentUser = JSON.parse(fs.readFileSync(userPath));
  let picturesToSend = [];

  if (currentUser.role === 'sidra') {
    picturesToSend = fs.readdirSync(USERS_DIR).map(file => {
      const user = JSON.parse(fs.readFileSync(path.join(USERS_DIR, file)));
      return { username: user.username, picture: user.picture };
    });
  } else {
    picturesToSend = [{ username: currentUser.username, picture: currentUser.picture }];
  }

  return res.json({ role: currentUser.role, username: currentUser.username, pictures: picturesToSend });
};

exports.deletePicture = (req, res) => {
  const { username } = req.body;
  if (!username) return res.status(400).send('Username required');

  const userPath = path.join(USERS_DIR, `${username}.json`);
  if (!fs.existsSync(userPath)) return res.status(404).send('User not found');

  const userData = JSON.parse(fs.readFileSync(userPath));
  const picturePath = path.join(UPLOADS_DIR, userData.picture);

  if (!userData.picture || !fs.existsSync(picturePath)) {
    return res.status(404).send('Picture not found');
  }

  fs.unlinkSync(picturePath);
  userData.picture = null;
  fs.writeFileSync(userPath, JSON.stringify(userData));

  return res.send('Your picture has been deleted successfully');
};
